# Retro Video Player (Android 5.0+)
Starter Android project using LibVLC for broad format support. Minimum SDK API 21 (Android 5.0); target SDK 28 for legacy compatibility.
Features: local video list, Android document picker for phone/SD card, full-screen playback, LibVLC hardware decoding preference.
Build: open in Android Studio with JDK 17 and Android SDK 35, sync Gradle, then Build > Build APK(s). Install debug APK on Android 5.0+.
Playback depends on codecs, device capability, and file integrity. This starter is a prototype; add playback controls, subtitle/audio menus, error handling, and test on target devices before release. If Android 4.x support is needed, minSdk and compatible LibVLC version must be changed. Review LibVLC license obligations before distribution.

package com.maqz.retroplayer;
import android.app.Activity;import android.content.Intent;import android.database.Cursor;import android.net.Uri;import android.os.Bundle;import android.provider.MediaStore;import android.view.View;import android.widget.*;import java.util.ArrayList;
public class MainActivity extends Activity{
private static final int PICK_VIDEO=100;private ArrayList<Uri> uris=new ArrayList<>();private ArrayList<String> names=new ArrayList<>();private ArrayAdapter<String> adapter;
@Override public void onCreate(Bundle b){super.onCreate(b);setContentView(R.layout.activity_main);ListView list=findViewById(R.id.list);
adapter=new ArrayAdapter<String>(this,android.R.layout.simple_list_item_1,names){@Override public View getView(int p,View v,android.view.ViewGroup parent){View row=super.getView(p,v,parent);((TextView)row.findViewById(android.R.id.text1)).setTextColor(0xffffffff);return row;}};list.setAdapter(adapter);list.setOnItemClickListener((a,v,pos,id)->play(uris.get(pos)));
findViewById(R.id.pick).setOnClickListener(v->{Intent i=new Intent(Intent.ACTION_OPEN_DOCUMENT);i.setType("video/*");i.addCategory(Intent.CATEGORY_OPENABLE);startActivityForResult(i,PICK_VIDEO);});loadVideos();}
private void loadVideos(){String[] proj={MediaStore.Video.Media._ID,MediaStore.Video.Media.DISPLAY_NAME};try(Cursor c=getContentResolver().query(MediaStore.Video.Media.EXTERNAL_CONTENT_URI,proj,null,null,MediaStore.Video.Media.DATE_ADDED+" DESC")){if(c!=null)while(c.moveToNext()){long id=c.getLong(0);uris.add(Uri.withAppendedPath(MediaStore.Video.Media.EXTERNAL_CONTENT_URI,String.valueOf(id)));names.add(c.getString(1));}}catch(Exception ignored){}adapter.notifyDataSetChanged();}
@Override protected void onActivityResult(int req,int res,Intent data){super.onActivityResult(req,res,data);if(req==PICK_VIDEO&&res==RESULT_OK&&data!=null){Uri u=data.getData();if(u!=null){try{getContentResolver().takePersistableUriPermission(u,Intent.FLAG_GRANT_READ_URI_PERMISSION);}catch(Exception ignored){}play(u);}}}
private void play(Uri u){Intent i=new Intent(this,PlayerActivity.class);i.setData(u);startActivity(i);}
}

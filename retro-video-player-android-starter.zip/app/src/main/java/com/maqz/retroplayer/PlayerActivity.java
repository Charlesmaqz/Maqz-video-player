package com.maqz.retroplayer;
import android.app.Activity;import android.net.Uri;import android.os.Bundle;import android.view.View;import android.widget.FrameLayout;import org.videolan.libvlc.LibVLC;import org.videolan.libvlc.Media;import org.videolan.libvlc.MediaPlayer;import org.videolan.libvlc.util.VLCVideoLayout;import java.util.ArrayList;
public class PlayerActivity extends Activity{
private LibVLC lib;private MediaPlayer player;private VLCVideoLayout video;
@Override public void onCreate(Bundle b){super.onCreate(b);getWindow().getDecorView().setSystemUiVisibility(View.SYSTEM_UI_FLAG_FULLSCREEN|View.SYSTEM_UI_FLAG_HIDE_NAVIGATION|View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY);Uri uri=getIntent().getData();if(uri==null){finish();return;}FrameLayout root=new FrameLayout(this);root.setBackgroundColor(0xff000000);video=new VLCVideoLayout(this);root.addView(video,new FrameLayout.LayoutParams(-1,-1));setContentView(root);ArrayList<String> opts=new ArrayList<>();opts.add("--avcodec-hw=any");opts.add("--no-sub-autodetect-file");lib=new LibVLC(this,opts);player=new MediaPlayer(lib);player.attachViews(video,null,false,false);Media media=new Media(lib,uri);player.setMedia(media);media.release();player.play();}
@Override protected void onPause(){super.onPause();if(player!=null)player.pause();}
@Override protected void onDestroy(){if(player!=null){player.stop();player.detachViews();player.release();}if(lib!=null)lib.release();super.onDestroy();}
}
